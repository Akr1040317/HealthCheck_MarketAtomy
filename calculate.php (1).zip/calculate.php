

<?php

session_start();

$email = $_SESSION['email'];

$conn= new mysqli("localhost","marketat_akshatR","akshat03","marketat_verify-user", 3306);

//Foundational Structure (Sections 2, 3, 5, 6 & 7)
$sql = "SELECT * from section2 "; 
foreach ($conn->query($sql) as $row)  
{  
    $total= (int)$row['question21'] + (int)$row['question22'] + (int)$row['question23'] + (int)$row['question24'] + (int)$row['question25'] + (int)$row['question26'] + (int)$row['question27'] + (int)$row['question28'] + (int)$row['question29'] + (int)$row['question210'] + (float)$row['question211'];
    $id = $row['id'];

    $sql="UPDATE section2 SET total='$total'  WHERE id = $id";
    mysqli_query($conn,$sql);

}

$sql = "SELECT * from section3 "; 
foreach ($conn->query($sql) as $row)  
{  
    $total= (int)$row['soleOwn'] + (int)$row['sepApprov'] + (int)$row['minority'] + (int)$row['stock'] + (int)$row['allianPart']; 
    $id = $row['id'];

    $sql="UPDATE section3 SET total='$total'  WHERE id = $id";
    mysqli_query($conn,$sql);
    
}

$sql = "SELECT * from section5 "; 
foreach ($conn->query($sql) as $row)  
{  
    $total= (int)$row['mileStones'] + (int)$row['pipeLine'] + (int)$row['performing'] + (int)$row['peopleInP'] + (int)$row['exitStrat']; 
    $id = $row['id'];

    $sql="UPDATE section5 SET total='$total'  WHERE id = $id";
    mysqli_query($conn,$sql);
    
}

$sql = "SELECT * from section6 "; 
foreach ($conn->query($sql) as $row)  
{  
    $total= (float)$row['operationSkills'] + (int)$row['homeOrAdd'] + (int)$row['employ'] + (int)$row['employFull'] + (int)$row['hr'] + (int)$row['it'] + (int)$row['defCulture'] + (int)$row['turnover'] + (int)$row['teamEng'] + (int)$row['polApro'] + (int)$row['jobDesc'] + (int)$row['review'] + (int)$row['benefits'] + (int)$row['newEmploy'] + (int)$row['external'] + (int)$row['partTime']; 
    $id = $row['id'];

    $sql="UPDATE section6 SET total='$total'  WHERE id = $id";
    mysqli_query($conn,$sql);
    
}

$sql = "SELECT * from section7 "; 
foreach ($conn->query($sql) as $row)  
{  
    $total= (int)$row['execFunct'] + (int)$row['othExe'] + (int)$row['prevBus'] + (int)$row['shares'] + (int)$row['invested'] + (int)$row['directEmploy'] + (int)$row['boDi'] + (int)$row['adBo'] + (int)$row['external']; 
    $id = $row['id'];

    $sql="UPDATE section7 SET total='$total'  WHERE id = $id";
    mysqli_query($conn,$sql);
    
}

//end

//Financial Position (Sections 4, 8, 11, 12, 16, 17 & 18)
$sql = "SELECT * from section4 "; 
foreach ($conn->query($sql) as $row)  
{  
    $total= (int)$row['finPos'] + (int)$row['financed'] + (int)$row['investPer'] + (int)$row['addInvF'] + (int)$row['raise'] + (int)$row['need'] + (int)$row['immedFunds']; 
    $id = $row['id'];

    $sql="UPDATE section4 SET total='$total'  WHERE id = $id";
    mysqli_query($conn,$sql);
    
}

$sql = "SELECT * from section8 "; 
foreach ($conn->query($sql) as $row)  
{  
    $total= (int)$row['sell'] + (int)$row['charac'] + (int)$row['provOCrea'] + (int)$row['manufact'] + (int)$row['mvp'] + (int)$row['netProfit'] + (int)$row['likeTo'] + (int)$row['drive']; 
    $id = $row['id'];

    $sql="UPDATE section8 SET total='$total'  WHERE id = $id";
    mysqli_query($conn,$sql);
    
}

$sql = "SELECT * from section11 "; 
foreach ($conn->query($sql) as $row)  
{  
    $total= (int)$row['limitingFactors'] + (int)$row['revStream'] + (int)$row['revStreamInc'] + (int)$row['salesPatterns'] + (int)$row['performance'] + (int)$row['realistic']; 
    $id = $row['id'];

    $sql="UPDATE section11 SET total='$total'  WHERE id = $id";
    mysqli_query($conn,$sql);
    
}

$sql = "SELECT * from section12 "; 
foreach ($conn->query($sql) as $row)  
{  
    $total= (int)$row['sales'] + (int)$row['projection'] + (int)$row['revenue'] + (int)$row['track'] + (int)$row['internal'] + (int)$row['responsible'] + (int)$row['salespeople'] + (int)$row['established'] + (int)$row['goals'] + (int)$row['training'] + (int)$row['relationship'] + (int)$row['cycle'] + (int)$row['export']; 
    $id = $row['id'];

    $sql="UPDATE section12 SET total='$total'  WHERE id = $id";
    mysqli_query($conn,$sql);
    
}

$sql = "SELECT * from section16 "; 
foreach ($conn->query($sql) as $row)  
{  
    $total= (int)$row['question161'] + (int)$row['question162'] + (int)$row['question163'] + (int)$row['question164'] + (int)$row['question165'] + (int)$row['question166'] + (int)$row['question167'] + (int)$row['question168'] + (int)$row['question169'] + (int)$row['question1610'] + (int)$row['question1611'] + (int)$row['question1612'] + (int)$row['question1613'] + (int)$row['question1614'] + (int)$row['question1615'] + (int)$row['question1616'] + (int)$row['question1617'] + (int)$row['question1618'] + (int)$row['question1619']; 
    $id = $row['id'];

    $sql="UPDATE section16 SET total='$total'  WHERE id = $id";
    mysqli_query($conn,$sql);
    
}

$sql = "SELECT * from section17 "; 
foreach ($conn->query($sql) as $row)  
{  
    $total= (int)$row['question171'] + (int)$row['question172'] + (int)$row['question173'] + (int)$row['question174'] + (int)$row['question175']; 
    $id = $row['id'];

    $sql="UPDATE section17 SET total='$total'  WHERE id = $id";
    mysqli_query($conn,$sql);
    
}

$sql = "SELECT * from section18 "; 
foreach ($conn->query($sql) as $row)  
{  
    $total= (int)$row['question1'] + (int)$row['question2'] + (int)$row['question3'] + (int)$row['question4'] + (int)$row['question5']; 
    $id = $row['id'];

    $sql="UPDATE section18 SET total='$total'  WHERE id = $id";
    mysqli_query($conn,$sql);
    
}
//end

//Sales/Marketing (Sections 10, 12, 13, 14 & 15)
$sql = "SELECT * from section10 "; 
foreach ($conn->query($sql) as $row)  
{  
    $total= (int)$row['sold'] + (int)$row['scale'] + (int)$row['future'] + (int)$row['profitable'] + (int)$row['geo'] + (int)$row['physical'] + (int)$row['market'] + (int)$row['product']; 
    $id = $row['id'];

    $sql="UPDATE section10 SET total='$total'  WHERE id = $id";
    mysqli_query($conn,$sql);
    
}

$sql = "SELECT * from section12 "; 
foreach ($conn->query($sql) as $row)  
{  
    $total= (int)$row['sales'] + (int)$row['projection'] + (int)$row['revenue'] + (int)$row['track'] + (int)$row['internal'] + (int)$row['responsible'] + (int)$row['salespeople'] + (int)$row['established'] + (int)$row['compensated'] + (int)$row['goals'] + (int)$row['training'] + (int)$row['relationship'] + (int)$row['cycle'] + (int)$row['export']; 
    $id = $row['id'];

    $sql="UPDATE section12 SET total='$total'  WHERE id = $id";
    mysqli_query($conn,$sql);
    
}

$sql = "SELECT * from section13 "; 
foreach ($conn->query($sql) as $row)  
{  
    $total= (int)$row['question131'] + (int)$row['question132'] + (int)$row['question133'] + (int)$row['question134'] + (int)$row['question135'] + (int)$row['question136'] + (int)$row['question137'] + (int)$row['question138'] + (int)$row['question139']; 
    $id = $row['id'];

    $sql="UPDATE section13 SET total='$total'  WHERE id = $id";
    mysqli_query($conn,$sql);
    
}

$sql = "SELECT * from section14 "; 
foreach ($conn->query($sql) as $row)  
{  
    $total= (int)$row['question141'] + (int)$row['question142'] + (int)$row['question143'] + (int)$row['question144'] + (int)$row['question145'] + (int)$row['question146'] + (int)$row['question147'] + (int)$row['question148'] + (int)$row['question149'] + (int)$row['question1410'] + (int)$row['question1411'] + (int)$row['question1412']; 
    $id = $row['id'];

    $sql="UPDATE section14 SET total='$total'  WHERE id = $id";
    mysqli_query($conn,$sql);
    
}

$sql = "SELECT * from section15 "; 
foreach ($conn->query($sql) as $row)  
{  
    $total= (int)$row['question151'] + (int)$row['question152'] + (int)$row['question153'] + (int)$row['question154'] + (int)$row['question155'] + (int)$row['question156'] + (int)$row['question157'] + (int)$row['question158'] + (int)$row['question159'] + (int)$row['question1510'] + (int)$row['question1511'] + (int)$row['question1512'] + (int)$row['question1513'] + (int)$row['question1514'] + (int)$row['question1515'] + (int)$row['question1516'] + (int)$row['question1517']; 
    $id = $row['id'];

    $sql="UPDATE section15 SET total='$total'  WHERE id = $id";
    mysqli_query($conn,$sql);
    
}
//end

//Product/Service (Sections 8, 9 & 19) 
$sql = "SELECT * from section8 "; 
foreach ($conn->query($sql) as $row)  
{  
    $total= (int)$row['sell'] + (int)$row['charac'] + (int)$row['provOCrea'] + (int)$row['manufact'] + (int)$row['mvp'] + (int)$row['netProfit'] + (int)$row['likeTo'] + (int)$row['drive']; 
    $id = $row['id'];

    $sql="UPDATE section8 SET total='$total'  WHERE id = $id";
    mysqli_query($conn,$sql);
    
}

$sql = "SELECT * from section9 "; 
foreach ($conn->query($sql) as $row)  
{  
    $total= (int)$row['prop'] + (int)$row['patents'] + (int)$row['ip'] + (int)$row['ipAttorney'] + (int)$row['infringement'] + (int)$row['counterfeit']; 
    $id = $row['id'];

    $sql="UPDATE section9 SET total='$total'  WHERE id = $id";
    mysqli_query($conn,$sql);
    
}

$sql = "SELECT * from section19 "; 
foreach ($conn->query($sql) as $row)  
{  
    $total= (int)$row['question191'] + (int)$row['question192'] + (int)$row['question193'] + (int)$row['question194'] + (int)$row['question195'] + (int)$row['question196'] + (int)$row['question197'] + (int)$row['question198'] + (int)$row['question199'] + (int)$row['question1910'] + (int)$row['question1911'] + (int)$row['question1912'] + (int)$row['question1913'] + (int)$row['question1914'] + (int)$row['question1915'] + (int)$row['question1916']; 
    $id = $row['id'];

    $sql="UPDATE section19 SET total='$total'  WHERE id = $id";
    mysqli_query($conn,$sql);
    
}
//end

//General (Sections 20 & 21)
$sql = "SELECT * from section20 "; 
foreach ($conn->query($sql) as $row)  
{  
    $total= (int)$row['question201'] +  (int)$row['question202'] + (int)$row['question203'] + (int)$row['question204'] + (int)$row['question205'] + (int)$row['question206'] + (int)$row['question207'] + (int)$row['question208'] + (int)$row['question209'] + (int)$row['question2010'] + (int)$row['question2011'] + (int)$row['question2012'] + (int)$row['question2013']; 
    $id = $row['id'];

    $sql="UPDATE section20 SET total='$total'  WHERE id = $id";
    mysqli_query($conn,$sql);
    
}

$sql = "SELECT * from section21 "; 
foreach ($conn->query($sql) as $row)  
{  
    $total= (int)$row['question211'] + (int)$row['question212'] + (int)$row['question213'] + (int)$row['question214'] + (int)$row['question215'] + (int)$row['question216'] + (int)$row['question217']; 
    $id = $row['id'];

    $sql="UPDATE section21 SET total='$total'  WHERE id = $id";
    mysqli_query($conn,$sql);
    
}
//end


//Final summing of entire test

//Foundational Structure (Sections 2, 3, 5, 6 & 7)

$sql_query = "SELECT `total` FROM `section2` WHERE `email` = '$email'";
$section_query = $conn->query($sql_query);
$section_total_array = $section_query->fetch_assoc();
$section2_total = (int)$section_total_array["total"];

$sql_query = "SELECT `total` FROM `section3` WHERE `email` = '$email'";
$section_query = $conn->query($sql_query);
$section_total_array = $section_query->fetch_assoc();
$section3_total = (int)$section_total_array["total"];

$sql_query = "SELECT `total` FROM `section5` WHERE `email` = '$email'";
$section_query = $conn->query($sql_query);
$section_total_array = $section_query->fetch_assoc();
$section5_total = (int)$section_total_array["total"];

$sql_query = "SELECT `total` FROM `section6` WHERE `email` = '$email'";
$section_query = $conn->query($sql_query);
$section_total_array = $section_query->fetch_assoc();
$section6_total = (int)$section_total_array["total"];

$sql_query = "SELECT `total` FROM `section7` WHERE `email` = '$email'";
$section_query = $conn->query($sql_query);
$section_total_array = $section_query->fetch_assoc();
$section7_total = (int)$section_total_array["total"];

$final_sum = $section2_total + $section3_total + $section5_total + $section6_total + $section7_total;

// Checks if a row already exists for the currently logged in email
$row_check = $conn->query("SELECT * FROM `totals` WHERE email ='$email' ");

if ( $row_check->num_rows > 0) {
    // Row already exists, so UPDATE
    $sql_query = "UPDATE `totals` SET FoundationStructure = '$final_sum' WHERE email = '$email' ";
} else {
    //Row does not exist, so INSERT
    $sql_query = "INSERT INTO `totals` (email, FoundationStructure) VALUES ('$email', $final_sum)";
}

$section_query = $conn->query($sql_query);


//Financial Position (Sections 4, 8, 11, 12, 16, 17 & 18)

$sql_query = "SELECT `total` FROM `section4` WHERE `email` = '$email'";
$section_query = $conn->query($sql_query);
$section_total_array = $section_query->fetch_assoc();
$section4_total = (int)$section_total_array["total"];

$sql_query = "SELECT `total` FROM `section8` WHERE `email` = '$email'";
$section_query = $conn->query($sql_query);
$section_total_array = $section_query->fetch_assoc();
$section8_total = (int)$section_total_array["total"];

$sql_query = "SELECT `total` FROM `section11` WHERE `email` = '$email'";
$section_query = $conn->query($sql_query);
$section_total_array = $section_query->fetch_assoc();
$section11_total = (int)$section_total_array["total"];

$sql_query = "SELECT `total` FROM `section12` WHERE `email` = '$email'";
$section_query = $conn->query($sql_query);
$section_total_array = $section_query->fetch_assoc();
$section12_total = (int)$section_total_array["total"];

$sql_query = "SELECT `total` FROM `section16` WHERE `email` = '$email'";
$section_query = $conn->query($sql_query);
$section_total_array = $section_query->fetch_assoc();
$section16_total = (int)$section_total_array["total"];

$sql_query = "SELECT `total` FROM `section17` WHERE `email` = '$email'";
$section_query = $conn->query($sql_query);
$section_total_array = $section_query->fetch_assoc();
$section17_total = (int)$section_total_array["total"];

$sql_query = "SELECT `total` FROM `section18` WHERE `email` = '$email'";
$section_query = $conn->query($sql_query);
$section_total_array = $section_query->fetch_assoc();
$section18_total = (int)$section_total_array["total"];

$final_sum = $section4_total + $section8_total + $section11_total + $section12_total + $section16_total + $section17_total + $section18_total;

// Checks if a row already exists for the currently logged in email
$row_check = $conn->query("SELECT * FROM `totals` WHERE email ='$email' ");

if ( $row_check->num_rows > 0) {
    // Row already exists, so UPDATE
    $sql_query = "UPDATE `totals` SET FinancialPosition = '$final_sum' WHERE email = '$email' ";
} else {
    //Row does not exist, so INSERT
    $sql_query = "INSERT INTO `totals` (email, FinancialPosition) VALUES ('$email', $final_sum)";
}

$section_query = $conn->query($sql_query);


//Sales/Marketing (Sections 10, 12, 13, 14 & 15)

$sql_query = "SELECT `total` FROM `section10` WHERE `email` = '$email'";
$section_query = $conn->query($sql_query);
$section_total_array = $section_query->fetch_assoc();
$section10_total = (int)$section_total_array["total"];

$sql_query = "SELECT `total` FROM `section12` WHERE `email` = '$email'";
$section_query = $conn->query($sql_query);
$section_total_array = $section_query->fetch_assoc();
$section12_total = (int)$section_total_array["total"];

$sql_query = "SELECT `total` FROM `section13` WHERE `email` = '$email'";
$section_query = $conn->query($sql_query);
$section_total_array = $section_query->fetch_assoc();
$section13_total = (int)$section_total_array["total"];

$sql_query = "SELECT `total` FROM `section14` WHERE `email` = '$email'";
$section_query = $conn->query($sql_query);
$section_total_array = $section_query->fetch_assoc();
$section14_total = (int)$section_total_array["total"];

$sql_query = "SELECT `total` FROM `section15` WHERE `email` = '$email'";
$section_query = $conn->query($sql_query);
$section_total_array = $section_query->fetch_assoc();
$section15_total = (int)$section_total_array["total"];



$final_sum = $section10_total + $section12_total + $section13_total + $section14_total + $section15_total;

// Checks if a row already exists for the currently logged in email
$row_check = $conn->query("SELECT * FROM `totals` WHERE email ='$email' ");

if ( $row_check->num_rows > 0) {
    // Row already exists, so UPDATE
    $sql_query = "UPDATE `totals` SET `Sales/Marketing` = '$final_sum' WHERE email = '$email' ";
} else {
    //Row does not exist, so INSERT
    $sql_query = "INSERT INTO `totals` (email, `Sales/Marketing`) VALUES ('$email', $final_sum)";
}

$section_query = $conn->query($sql_query);





//Product/Service (Sections 8, 9 & 19) 

$sql_query = "SELECT `total` FROM `section8` WHERE `email` = '$email'";
$section_query = $conn->query($sql_query);
$section_total_array = $section_query->fetch_assoc();
$section8_total = (int)$section_total_array["total"];

$sql_query = "SELECT `total` FROM `section9` WHERE `email` = '$email'";
$section_query = $conn->query($sql_query);
$section_total_array = $section_query->fetch_assoc();
$section9_total = (int)$section_total_array["total"];

$sql_query = "SELECT `total` FROM `section19` WHERE `email` = '$email'";
$section_query = $conn->query($sql_query);
$section_total_array = $section_query->fetch_assoc();
$section19_total = (int)$section_total_array["total"];

$final_sum = $section8_total + $section9_total + $section19_total;

// Checks if a row already exists for the currently logged in email
$row_check = $conn->query("SELECT * FROM `totals` WHERE email ='$email' ");

if ( $row_check->num_rows > 0) {
    // Row already exists, so UPDATE
    $sql_query = "UPDATE `totals` SET `Product/Service` = '$final_sum' WHERE email = '$email' ";
} else {
    //Row does not exist, so INSERT
    $sql_query = "INSERT INTO `totals` (email, `Product/Service`) VALUES ('$email', $final_sum)";
}

$section_query = $conn->query($sql_query);

//General (Sections 20, 21)

$sql_query = "SELECT `total` FROM `section20` WHERE `email` = '$email'";
$section_query = $conn->query($sql_query);
$section_total_array = $section_query->fetch_assoc();
$section20_total = (int)$section_total_array["total"];

$sql_query = "SELECT `total` FROM `section21` WHERE `email` = '$email'";
$section_query = $conn->query($sql_query);
$section_total_array = $section_query->fetch_assoc();
$section21_total = (int)$section_total_array["total"];


$final_sum = $section20_total + $section21_total;

// Checks if a row already exists for the currently logged in email
$row_check = $conn->query("SELECT * FROM `totals` WHERE email ='$email' ");

if ( $row_check->num_rows > 0) {
    // Row already exists, so UPDATE
    $sql_query = "UPDATE `totals` SET General = '$final_sum' WHERE email = '$email' ";
} else {
    //Row does not exist, so INSERT
    $sql_query = "INSERT INTO `totals` (email, General) VALUES ('$email', $final_sum)";
}

$section_query = $conn->query($sql_query);


$conn->close();

?>

<!DOCTYPE html>
<html lang="en-US" class="no-js no-svg">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <title>BHC Assessment Scoring Report &#8211; MarketAtomy</title>
<!--[if lt IE 9]><script>document.createElement('');</script><![endif]-->
	<link rel='dns-prefetch' href='//a.omappapi.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="MarketAtomy &raquo; Feed" href="https://www.marketatomy.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="MarketAtomy &raquo; Comments Feed" href="https://www.marketatomy.com/comments/feed/" />
<link rel="alternate" type="text/calendar" title="MarketAtomy &raquo; iCal Feed" href="https://www.marketatomy.com/events/?ical=1" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/www.marketatomy.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.4.5"}};
			/*! This file is auto-generated */
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='op3-frontend-stylesheet-css'  href='https://www.marketatomy.com/wp-content/plugins/op-builder/public/assets/cache/page-16288.css?ver=925707738a5757bf276d595acb834803' type='text/css' media='all' />
<script type='text/javascript'>
/* <![CDATA[ */
var startappCore = {"ajaxurl":"https:\/\/www.marketatomy.com\/wp-admin\/admin-ajax.php","nonce":"7245c0f931"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.marketatomy.com/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp'></script>
<script type='text/javascript' src='https://www.marketatomy.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<link rel='https://api.w.org/' href='https://www.marketatomy.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.marketatomy.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://www.marketatomy.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.4.5" />
<link rel="canonical" href="https://www.marketatomy.com/bhc-assessment-scoring-report/" />
<link rel='shortlink' href='https://www.marketatomy.com/?p=16288' />
<link rel="alternate" type="application/json+oembed" href="https://www.marketatomy.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fwww.marketatomy.com%2Fbhc-assessment-scoring-report%2F" />
<link rel="alternate" type="text/xml+oembed" href="https://www.marketatomy.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fwww.marketatomy.com%2Fbhc-assessment-scoring-report%2F&#038;format=xml" />
<link type="text/css" rel="stylesheet" href="https://www.marketatomy.com/wp-content/plugins/category-specific-rss-feed-menu/wp_cat_rss_style.css" />
<meta name="et-api-version" content="v1"><meta name="et-api-origin" content="https://www.marketatomy.com"><link rel="https://theeventscalendar.com/" href="https://www.marketatomy.com/wp-json/tribe/tickets/v1/" /><meta name="tec-api-version" content="v1"><meta name="tec-api-origin" content="https://www.marketatomy.com"><link rel="https://theeventscalendar.com/" href="https://www.marketatomy.com/wp-json/tribe/events/v1/" /><style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><meta name="generator" content="Powered by Visual Composer - drag and drop page builder for WordPress."/>
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="https://www.marketatomy.com/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]-->
        <!--[if (gte IE 6)&(lte IE 8)]>
            <script type="text/javascript" src="https://www.marketatomy.com/wp-content/plugins/optimizePressPlugin/lib/js/selectivizr-1.0.2-min.js?ver=1.0.2"></script>
        <![endif]-->
        <!--[if lt IE 9]>
            <script src="https://www.marketatomy.com/wp-content/plugins/optimizePressPlugin/lib/js//html5shiv.min.js"></script>
        <![endif]-->
    <meta name="generator" content="Powered by Slider Revolution 6.4.6 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Anton|IBM+Plex+Sans:400,700|Poppins:400,700" />

<script type="text/javascript">function setREVStartSize(e){
			//window.requestAnimationFrame(function() {				 
				window.RSIW = window.RSIW===undefined ? window.innerWidth : window.RSIW;	
				window.RSIH = window.RSIH===undefined ? window.innerHeight : window.RSIH;	
				try {								
					var pw = document.getElementById(e.c).parentNode.offsetWidth,
						newh;
					pw = pw===0 || isNaN(pw) ? window.RSIW : pw;
					e.tabw = e.tabw===undefined ? 0 : parseInt(e.tabw);
					e.thumbw = e.thumbw===undefined ? 0 : parseInt(e.thumbw);
					e.tabh = e.tabh===undefined ? 0 : parseInt(e.tabh);
					e.thumbh = e.thumbh===undefined ? 0 : parseInt(e.thumbh);
					e.tabhide = e.tabhide===undefined ? 0 : parseInt(e.tabhide);
					e.thumbhide = e.thumbhide===undefined ? 0 : parseInt(e.thumbhide);
					e.mh = e.mh===undefined || e.mh=="" || e.mh==="auto" ? 0 : parseInt(e.mh,0);		
					if(e.layout==="fullscreen" || e.l==="fullscreen") 						
						newh = Math.max(e.mh,window.RSIH);					
					else{					
						e.gw = Array.isArray(e.gw) ? e.gw : [e.gw];
						for (var i in e.rl) if (e.gw[i]===undefined || e.gw[i]===0) e.gw[i] = e.gw[i-1];					
						e.gh = e.el===undefined || e.el==="" || (Array.isArray(e.el) && e.el.length==0)? e.gh : e.el;
						e.gh = Array.isArray(e.gh) ? e.gh : [e.gh];
						for (var i in e.rl) if (e.gh[i]===undefined || e.gh[i]===0) e.gh[i] = e.gh[i-1];
											
						var nl = new Array(e.rl.length),
							ix = 0,						
							sl;					
						e.tabw = e.tabhide>=pw ? 0 : e.tabw;
						e.thumbw = e.thumbhide>=pw ? 0 : e.thumbw;
						e.tabh = e.tabhide>=pw ? 0 : e.tabh;
						e.thumbh = e.thumbhide>=pw ? 0 : e.thumbh;					
						for (var i in e.rl) nl[i] = e.rl[i]<window.RSIW ? 0 : e.rl[i];
						sl = nl[0];									
						for (var i in nl) if (sl>nl[i] && nl[i]>0) { sl = nl[i]; ix=i;}															
						var m = pw>(e.gw[ix]+e.tabw+e.thumbw) ? 1 : (pw-(e.tabw+e.thumbw)) / (e.gw[ix]);					
						newh =  (e.gh[ix] * m) + (e.tabh + e.thumbh);
					}				
					if(window.rs_init_css===undefined) window.rs_init_css = document.head.appendChild(document.createElement("style"));					
					document.getElementById(e.c).height = newh+"px";
					window.rs_init_css.innerHTML += "#"+e.c+"_wrapper { height: "+newh+"px }";				
				} catch(e){
					console.log("Failure at Presize of Slider:" + e)
				}					   
			//});
		  };</script>
<noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style id="op3-custom-css"></style></head>

<body data-rsssl=1 class="page-template page-template-op_builder_blank page page-id-16288 op-plugin tribe-no-js op-navbar-fixed op-navbar-fixed-header-style-basic wpb-js-composer js-comp-ver-5.0.1 vc_responsive elementor-default elementor-kit-16081">
<h1>
<?php 
    
    session_start();

$email = $_SESSION['email'];
$sql = "SELECT FoundationStructure FROM totals WHERE email ='$email'";
$result = mysqli_query($conn,$sql);
echo $result;
?>
</h1>
<div id="op3-designer-element" >
<div data-op3-children="16"><div id="op3-element-ElHXluwN" class="op3-element " data-op3-uuid="ElHXluwN" data-op3-gid="" data-op3-element-type="section" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="video" data-op3-src="" data-op3-video-source="embed" data-op3-video-url-youtube="" data-op3-video-url-vimeo="" data-op3-video-url-wistia="" data-op3-video-autoplay="1" data-op3-video-mute="1" data-op3-video-loop="1" data-op3-video-controls="0" data-op3-video-modest-branding="1" data-op3-video-related="0" data-op3-video-color="#00adef" data-op3-video-background="1" data-op3-video-byline="0" data-op3-video-portrait="0" data-op3-video-title="0" data-op3-video-speed="0" data-op3-video-start-time="00:00" data-op3-show-on-mobile="1"><div data-op3-code data-op3-aspect-ratio="16:9"></div></div><div data-op3-background="overlay"></div><div data-op3-background="separatorTop"></div><div data-op3-background="separatorBottom"></div></div><div data-op3-children="1"><div id="op3-element-kelOulfB" class="op3-element " data-op3-uuid="kelOulfB" data-op3-gid="" data-op3-element-type="row" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="2" data-op3-stack-columns-tablet="0" data-op3-stack-columns-tablet-reverse="0" data-op3-stack-columns-mobile="1" data-op3-stack-columns-mobile-reverse="0" data-op3-wrap-columns="0"><div id="op3-element-uevmHQsH" class="op3-element " data-op3-uuid="uevmHQsH" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-Sh4aRn0Z" class="op3-element " data-op3-uuid="Sh4aRn0Z" data-op3-gid="" data-op3-element-type="image" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><figure class="op3-background-ancestor" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><a  target="_self"  data-op-action="link" data-op-popoverlay-trigger="none" data-op-select-funnel-step=""><div class="op3-image-overlay-container"><img src="https://www.marketatomy.com/wp-content/uploads/2020/02/BHC-Final-Horizontal-1024x440.png" alt="" title="BHC Final Horizontal" width="1024" height="440" /><div data-op3-background="overlay"></div></div></a></figure></div></div></div></div></div><div id="op3-element-GhZ1ZG3T" class="op3-element " data-op3-uuid="GhZ1ZG3T" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="2"><div id="op3-element-6VhdjlAy" class="op3-element " data-op3-uuid="6VhdjlAy" data-op3-gid="" data-op3-element-type="text" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-text-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><h4><b><i>Powered by MarketAtomy LLC</i></b></h4></div></div></div><div id="op3-element-Aqaxvapj" class="op3-element " data-op3-uuid="Aqaxvapj" data-op3-gid="" data-op3-element-type="text" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-text-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><p>10151 University Boulevard #346</p><p>Orlando, FL 32817</p><p><a href="https://www.marketatomy.com" target="_blank">marketatomy.com</a></p></div></div></div></div></div></div></div></div></div></div></div></div></div><div id="op3-element-1VJ4JWR8" class="op3-element " data-op3-uuid="1VJ4JWR8" data-op3-gid="" data-op3-element-type="section" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="video" data-op3-src="" data-op3-video-source="embed" data-op3-video-url-youtube="" data-op3-video-url-vimeo="" data-op3-video-url-wistia="" data-op3-video-autoplay="1" data-op3-video-mute="1" data-op3-video-loop="1" data-op3-video-controls="0" data-op3-video-modest-branding="1" data-op3-video-related="0" data-op3-video-color="#00adef" data-op3-video-background="1" data-op3-video-byline="0" data-op3-video-portrait="0" data-op3-video-title="0" data-op3-video-speed="0" data-op3-video-start-time="00:00" data-op3-show-on-mobile="1"><div data-op3-code data-op3-aspect-ratio="16:9"></div></div><div data-op3-background="overlay"></div><div data-op3-background="separatorTop"></div><div data-op3-background="separatorBottom"></div></div><div data-op3-children="1"><div id="op3-element-8MDvthAK" class="op3-element " data-op3-uuid="8MDvthAK" data-op3-gid="" data-op3-element-type="row" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1" data-op3-stack-columns-tablet="0" data-op3-stack-columns-tablet-reverse="0" data-op3-stack-columns-mobile="1" data-op3-stack-columns-mobile-reverse="0" data-op3-wrap-columns="0"><div id="op3-element-8hEwwfqh" class="op3-element " data-op3-uuid="8hEwwfqh" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-8WvSLgCZ" class="op3-element " data-op3-uuid="8WvSLgCZ" data-op3-gid="" data-op3-element-type="headline" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-headline-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><h2>Here Is Your Assessment Scoring Report</h2></div></div></div></div></div></div></div></div></div></div></div></div></div><div id="op3-element-DBaIw8Hn" class="op3-element " data-op3-uuid="DBaIw8Hn" data-op3-gid="" data-op3-element-type="section" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="video" data-op3-src="" data-op3-video-source="embed" data-op3-video-url-youtube="" data-op3-video-url-vimeo="" data-op3-video-url-wistia="" data-op3-video-autoplay="1" data-op3-video-mute="1" data-op3-video-loop="1" data-op3-video-controls="0" data-op3-video-modest-branding="1" data-op3-video-related="0" data-op3-video-color="#00adef" data-op3-video-background="1" data-op3-video-byline="0" data-op3-video-portrait="0" data-op3-video-title="0" data-op3-video-speed="0" data-op3-video-start-time="00:00" data-op3-show-on-mobile="1"><div data-op3-code data-op3-aspect-ratio="16:9"></div></div><div data-op3-background="overlay"></div><div data-op3-background="separatorTop"></div><div data-op3-background="separatorBottom"></div></div><div data-op3-children="1"><div id="op3-element-69r5EEAs" class="op3-element " data-op3-uuid="69r5EEAs" data-op3-gid="" data-op3-element-type="row" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1" data-op3-stack-columns-tablet="0" data-op3-stack-columns-tablet-reverse="0" data-op3-stack-columns-mobile="1" data-op3-stack-columns-mobile-reverse="0" data-op3-wrap-columns="0"><div id="op3-element-0HG4CF9f" class="op3-element " data-op3-uuid="0HG4CF9f" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-hkqbyavG" class="op3-element " data-op3-uuid="hkqbyavG" data-op3-gid="" data-op3-element-type="text" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-text-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><p><span style="color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 14.4px;"><i>Information, data and concepts embodied in this document are proprietary to MarketAtomy, LLC and are strictly confidential and are supplied on the understanding that they will be held confidentially, and not disclosed to third parties without the prior written consent of MarketAtomy, LLC.</i></span><br></p></div></div></div></div></div></div></div></div></div></div></div></div></div><div id="op3-element-GH5fP2BW" class="op3-element " data-op3-uuid="GH5fP2BW" data-op3-gid="" data-op3-element-type="section" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="video" data-op3-src="" data-op3-video-source="embed" data-op3-video-url-youtube="" data-op3-video-url-vimeo="" data-op3-video-url-wistia="" data-op3-video-autoplay="1" data-op3-video-mute="1" data-op3-video-loop="1" data-op3-video-controls="0" data-op3-video-modest-branding="1" data-op3-video-related="0" data-op3-video-color="#00adef" data-op3-video-background="1" data-op3-video-byline="0" data-op3-video-portrait="0" data-op3-video-title="0" data-op3-video-speed="0" data-op3-video-start-time="00:00" data-op3-show-on-mobile="1"><div data-op3-code data-op3-aspect-ratio="16:9"></div></div><div data-op3-background="overlay"></div><div data-op3-background="separatorTop"></div><div data-op3-background="separatorBottom"></div></div><div data-op3-children="1"><div id="op3-element-BwAn9bHP" class="op3-element " data-op3-uuid="BwAn9bHP" data-op3-gid="" data-op3-element-type="row" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1" data-op3-stack-columns-tablet="0" data-op3-stack-columns-tablet-reverse="0" data-op3-stack-columns-mobile="1" data-op3-stack-columns-mobile-reverse="0" data-op3-wrap-columns="0"><div id="op3-element-gKCOfsZq" class="op3-element " data-op3-uuid="gKCOfsZq" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-iyV4mo4S" class="op3-element " data-op3-uuid="iyV4mo4S" data-op3-gid="" data-op3-element-type="headline" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-headline-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><h2><span style="color: rgb(241, 241, 247); background-color: rgb(0, 0, 0);">Overall Scoring</span></h2></div></div></div></div></div></div></div></div></div></div></div></div></div><div id="op3-element-ALL4Zdmk" class="op3-element " data-op3-uuid="ALL4Zdmk" data-op3-gid="" data-op3-element-type="section" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="video" data-op3-src="" data-op3-video-source="embed" data-op3-video-url-youtube="" data-op3-video-url-vimeo="" data-op3-video-url-wistia="" data-op3-video-autoplay="1" data-op3-video-mute="1" data-op3-video-loop="1" data-op3-video-controls="0" data-op3-video-modest-branding="1" data-op3-video-related="0" data-op3-video-color="#00adef" data-op3-video-background="1" data-op3-video-byline="0" data-op3-video-portrait="0" data-op3-video-title="0" data-op3-video-speed="0" data-op3-video-start-time="00:00" data-op3-show-on-mobile="1"><div data-op3-code data-op3-aspect-ratio="16:9"></div></div><div data-op3-background="overlay"></div><div data-op3-background="separatorTop"></div><div data-op3-background="separatorBottom"></div></div><div data-op3-children="1"><div id="op3-element-MhOtjRsk" class="op3-element " data-op3-uuid="MhOtjRsk" data-op3-gid="" data-op3-element-type="row" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="4" data-op3-stack-columns-tablet="0" data-op3-stack-columns-tablet-reverse="0" data-op3-stack-columns-mobile="1" data-op3-stack-columns-mobile-reverse="0" data-op3-wrap-columns="0"><div id="op3-element-8YQaJ5WB" class="op3-element " data-op3-uuid="8YQaJ5WB" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-Qq7jz31W" class="op3-element " data-op3-uuid="Qq7jz31W" data-op3-gid="" data-op3-element-type="headline" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-headline-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><h2 id = "initial percentage">60%</h2></div></div></div></div></div></div></div><div id="op3-element-p8wKnCQm" class="op3-element " data-op3-uuid="p8wKnCQm" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-JrnstNZH" class="op3-element " data-op3-uuid="JrnstNZH" data-op3-gid="" data-op3-element-type="headline" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-headline-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><h2>Foundational/Organizational Structure<br>Financial Strength and Position<br>Sales and Marketing Strength<br>Product/Service Viability<br>General Health</h2></div></div></div></div></div></div></div><div id="op3-element-qC5sxn1q" class="op3-element " data-op3-uuid="qC5sxn1q" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="0"></div></div></div></div><div id="op3-element-I4zzjYoJ" class="op3-element " data-op3-uuid="I4zzjYoJ" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-A6t7jHxS" class="op3-element " data-op3-uuid="A6t7jHxS" data-op3-gid="" data-op3-element-type="headline" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-headline-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><h2 id="FOS Score">000</h2><h2 id="FSP Score">000</h2><h2 id="SMS Score">000</h2><h2 id="PSV Score">000</h2><h2 id="GH Score">000</h2></div></div></div></div></div></div></div></div></div></div></div></div></div><div id="op3-element-aX8NkwpK" class="op3-element " data-op3-uuid="aX8NkwpK" data-op3-gid="" data-op3-element-type="section" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="video" data-op3-src="" data-op3-video-source="embed" data-op3-video-url-youtube="" data-op3-video-url-vimeo="" data-op3-video-url-wistia="" data-op3-video-autoplay="1" data-op3-video-mute="1" data-op3-video-loop="1" data-op3-video-controls="0" data-op3-video-modest-branding="1" data-op3-video-related="0" data-op3-video-color="#00adef" data-op3-video-background="1" data-op3-video-byline="0" data-op3-video-portrait="0" data-op3-video-title="0" data-op3-video-speed="0" data-op3-video-start-time="00:00" data-op3-show-on-mobile="1"><div data-op3-code data-op3-aspect-ratio="16:9"></div></div><div data-op3-background="overlay"></div><div data-op3-background="separatorTop"></div><div data-op3-background="separatorBottom"></div></div><div data-op3-children="1"><div id="op3-element-uCm3K2uc" class="op3-element " data-op3-uuid="uCm3K2uc" data-op3-gid="" data-op3-element-type="row" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="3" data-op3-stack-columns-tablet="0" data-op3-stack-columns-tablet-reverse="0" data-op3-stack-columns-mobile="1" data-op3-stack-columns-mobile-reverse="0" data-op3-wrap-columns="0"><div id="op3-element-luVTZmXj" class="op3-element " data-op3-uuid="luVTZmXj" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-0OFVSCcC" class="op3-element " data-op3-uuid="0OFVSCcC" data-op3-gid="" data-op3-element-type="headline" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-headline-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><h2><span style="color: rgb(241, 241, 247); background-color: rgb(0, 0, 0);">Foundational/Organizational Structure</span></h2></div></div></div></div></div></div></div><div id="op3-element-1uhAh8U7" class="op3-element " data-op3-uuid="1uhAh8U7" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-h2kEpZVL" class="op3-element " data-op3-uuid="h2kEpZVL" data-op3-gid="" data-op3-element-type="headline" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-headline-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><h2>00/</h2></div></div></div></div></div></div></div><div id="op3-element-RTDg9VgT" class="op3-element " data-op3-uuid="RTDg9VgT" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-ZimLmjqK" class="op3-element " data-op3-uuid="ZimLmjqK" data-op3-gid="" data-op3-element-type="headline" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-headline-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><h2>000</h2></div></div></div></div></div></div></div></div></div></div></div></div></div><div id="op3-element-3zhlvEGe" class="op3-element " data-op3-uuid="3zhlvEGe" data-op3-gid="" data-op3-element-type="section" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="video" data-op3-src="" data-op3-video-source="embed" data-op3-video-url-youtube="" data-op3-video-url-vimeo="" data-op3-video-url-wistia="" data-op3-video-autoplay="1" data-op3-video-mute="1" data-op3-video-loop="1" data-op3-video-controls="0" data-op3-video-modest-branding="1" data-op3-video-related="0" data-op3-video-color="#00adef" data-op3-video-background="1" data-op3-video-byline="0" data-op3-video-portrait="0" data-op3-video-title="0" data-op3-video-speed="0" data-op3-video-start-time="00:00" data-op3-show-on-mobile="1"><div data-op3-code data-op3-aspect-ratio="16:9"></div></div><div data-op3-background="overlay"></div><div data-op3-background="separatorTop"></div><div data-op3-background="separatorBottom"></div></div><div data-op3-children="1"><div id="op3-element-iP7bB5vl" class="op3-element " data-op3-uuid="iP7bB5vl" data-op3-gid="" data-op3-element-type="row" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1" data-op3-stack-columns-tablet="0" data-op3-stack-columns-tablet-reverse="0" data-op3-stack-columns-mobile="1" data-op3-stack-columns-mobile-reverse="0" data-op3-wrap-columns="0"><div id="op3-element-rUEjg05k" class="op3-element " data-op3-uuid="rUEjg05k" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-VF4xtDoa" class="op3-element " data-op3-uuid="VF4xtDoa" data-op3-gid="" data-op3-element-type="text" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-text-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><p>Purus ad semper aliquam nunc ad diam donec commodo. Amet justo placerat condimentum! Inceptos phasellus leo erat nisl? Dictumst pulvinar ornare maecenas vitae sodales sollicitudin sit enim sapien placerat auctor! Dui habitant vivamus conubia donec, malesuada leo, vestibulum primis. Consequat feugiat diam congue ut gravida sodales senectus praesent, diam vitae.</p></div></div></div></div></div></div></div></div></div></div></div></div></div><div id="op3-element-lYVT4O8X" class="op3-element " data-op3-uuid="lYVT4O8X" data-op3-gid="" data-op3-element-type="section" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="video" data-op3-src="" data-op3-video-source="embed" data-op3-video-url-youtube="" data-op3-video-url-vimeo="" data-op3-video-url-wistia="" data-op3-video-autoplay="1" data-op3-video-mute="1" data-op3-video-loop="1" data-op3-video-controls="0" data-op3-video-modest-branding="1" data-op3-video-related="0" data-op3-video-color="#00adef" data-op3-video-background="1" data-op3-video-byline="0" data-op3-video-portrait="0" data-op3-video-title="0" data-op3-video-speed="0" data-op3-video-start-time="00:00" data-op3-show-on-mobile="1"><div data-op3-code data-op3-aspect-ratio="16:9"></div></div><div data-op3-background="overlay"></div><div data-op3-background="separatorTop"></div><div data-op3-background="separatorBottom"></div></div><div data-op3-children="1"><div id="op3-element-ToSajREk" class="op3-element " data-op3-uuid="ToSajREk" data-op3-gid="" data-op3-element-type="row" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="3" data-op3-stack-columns-tablet="0" data-op3-stack-columns-tablet-reverse="0" data-op3-stack-columns-mobile="1" data-op3-stack-columns-mobile-reverse="0" data-op3-wrap-columns="0"><div id="op3-element-t36buW8x" class="op3-element " data-op3-uuid="t36buW8x" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-oSX9gxOa" class="op3-element " data-op3-uuid="oSX9gxOa" data-op3-gid="" data-op3-element-type="headline" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-headline-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><h2><span style="color: rgb(241, 241, 247); background-color: rgb(0, 0, 0);">Financial Strength/Positioning</span></h2></div></div></div></div></div></div></div><div id="op3-element-a7WRxRpP" class="op3-element " data-op3-uuid="a7WRxRpP" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-rorJggtG" class="op3-element " data-op3-uuid="rorJggtG" data-op3-gid="" data-op3-element-type="headline" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-headline-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><h2>00/</h2></div></div></div></div></div></div></div><div id="op3-element-YN5t1OM3" class="op3-element " data-op3-uuid="YN5t1OM3" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-l4i2WDeu" class="op3-element " data-op3-uuid="l4i2WDeu" data-op3-gid="" data-op3-element-type="headline" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-headline-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><h2>000</h2></div></div></div></div></div></div></div></div></div></div></div></div></div><div id="op3-element-d73LEp3m" class="op3-element " data-op3-uuid="d73LEp3m" data-op3-gid="" data-op3-element-type="section" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="video" data-op3-src="" data-op3-video-source="embed" data-op3-video-url-youtube="" data-op3-video-url-vimeo="" data-op3-video-url-wistia="" data-op3-video-autoplay="1" data-op3-video-mute="1" data-op3-video-loop="1" data-op3-video-controls="0" data-op3-video-modest-branding="1" data-op3-video-related="0" data-op3-video-color="#00adef" data-op3-video-background="1" data-op3-video-byline="0" data-op3-video-portrait="0" data-op3-video-title="0" data-op3-video-speed="0" data-op3-video-start-time="00:00" data-op3-show-on-mobile="1"><div data-op3-code data-op3-aspect-ratio="16:9"></div></div><div data-op3-background="overlay"></div><div data-op3-background="separatorTop"></div><div data-op3-background="separatorBottom"></div></div><div data-op3-children="1"><div id="op3-element-ioXeQCU0" class="op3-element " data-op3-uuid="ioXeQCU0" data-op3-gid="" data-op3-element-type="row" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1" data-op3-stack-columns-tablet="0" data-op3-stack-columns-tablet-reverse="0" data-op3-stack-columns-mobile="1" data-op3-stack-columns-mobile-reverse="0" data-op3-wrap-columns="0"><div id="op3-element-Mq44wDPX" class="op3-element " data-op3-uuid="Mq44wDPX" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-WKEfhSDk" class="op3-element " data-op3-uuid="WKEfhSDk" data-op3-gid="" data-op3-element-type="text" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-text-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><p>Purus ad semper aliquam nunc ad diam donec commodo. Amet justo placerat condimentum! Inceptos phasellus leo erat nisl? Dictumst pulvinar ornare maecenas vitae sodales sollicitudin sit enim sapien placerat auctor! Dui habitant vivamus conubia donec, malesuada leo, vestibulum primis. Consequat feugiat diam congue ut gravida sodales senectus praesent, diam vitae.</p></div></div></div></div></div></div></div></div></div></div></div></div></div><div id="op3-element-9XqX1gHQ" class="op3-element " data-op3-uuid="9XqX1gHQ" data-op3-gid="" data-op3-element-type="section" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="video" data-op3-src="" data-op3-video-source="embed" data-op3-video-url-youtube="" data-op3-video-url-vimeo="" data-op3-video-url-wistia="" data-op3-video-autoplay="1" data-op3-video-mute="1" data-op3-video-loop="1" data-op3-video-controls="0" data-op3-video-modest-branding="1" data-op3-video-related="0" data-op3-video-color="#00adef" data-op3-video-background="1" data-op3-video-byline="0" data-op3-video-portrait="0" data-op3-video-title="0" data-op3-video-speed="0" data-op3-video-start-time="00:00" data-op3-show-on-mobile="1"><div data-op3-code data-op3-aspect-ratio="16:9"></div></div><div data-op3-background="overlay"></div><div data-op3-background="separatorTop"></div><div data-op3-background="separatorBottom"></div></div><div data-op3-children="1"><div id="op3-element-hxoidran" class="op3-element " data-op3-uuid="hxoidran" data-op3-gid="" data-op3-element-type="row" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="3" data-op3-stack-columns-tablet="0" data-op3-stack-columns-tablet-reverse="0" data-op3-stack-columns-mobile="1" data-op3-stack-columns-mobile-reverse="0" data-op3-wrap-columns="0"><div id="op3-element-CsGxMl3N" class="op3-element " data-op3-uuid="CsGxMl3N" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-FGW5d3PT" class="op3-element " data-op3-uuid="FGW5d3PT" data-op3-gid="" data-op3-element-type="headline" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-headline-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><h2><span style="color: rgb(241, 241, 247); background-color: rgb(0, 0, 0);">Sales and Marketing Efforts</span></h2></div></div></div></div></div></div></div><div id="op3-element-lBbqZiu8" class="op3-element " data-op3-uuid="lBbqZiu8" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-N71fOvbJ" class="op3-element " data-op3-uuid="N71fOvbJ" data-op3-gid="" data-op3-element-type="headline" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-headline-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><h2>00/</h2></div></div></div></div></div></div></div><div id="op3-element-rVXzGKUW" class="op3-element " data-op3-uuid="rVXzGKUW" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-EHGJwI4y" class="op3-element " data-op3-uuid="EHGJwI4y" data-op3-gid="" data-op3-element-type="headline" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-headline-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><h2>000</h2></div></div></div></div></div></div></div></div></div></div></div></div></div><div id="op3-element-75nwt7uN" class="op3-element " data-op3-uuid="75nwt7uN" data-op3-gid="" data-op3-element-type="section" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="video" data-op3-src="" data-op3-video-source="embed" data-op3-video-url-youtube="" data-op3-video-url-vimeo="" data-op3-video-url-wistia="" data-op3-video-autoplay="1" data-op3-video-mute="1" data-op3-video-loop="1" data-op3-video-controls="0" data-op3-video-modest-branding="1" data-op3-video-related="0" data-op3-video-color="#00adef" data-op3-video-background="1" data-op3-video-byline="0" data-op3-video-portrait="0" data-op3-video-title="0" data-op3-video-speed="0" data-op3-video-start-time="00:00" data-op3-show-on-mobile="1"><div data-op3-code data-op3-aspect-ratio="16:9"></div></div><div data-op3-background="overlay"></div><div data-op3-background="separatorTop"></div><div data-op3-background="separatorBottom"></div></div><div data-op3-children="1"><div id="op3-element-Hfyb62zY" class="op3-element " data-op3-uuid="Hfyb62zY" data-op3-gid="" data-op3-element-type="row" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1" data-op3-stack-columns-tablet="0" data-op3-stack-columns-tablet-reverse="0" data-op3-stack-columns-mobile="1" data-op3-stack-columns-mobile-reverse="0" data-op3-wrap-columns="0"><div id="op3-element-OVNb2OgP" class="op3-element " data-op3-uuid="OVNb2OgP" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-asmcocI1" class="op3-element " data-op3-uuid="asmcocI1" data-op3-gid="" data-op3-element-type="text" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-text-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><p>Purus ad semper aliquam nunc ad diam donec commodo. Amet justo placerat condimentum! Inceptos phasellus leo erat nisl? Dictumst pulvinar ornare maecenas vitae sodales sollicitudin sit enim sapien placerat auctor! Dui habitant vivamus conubia donec, malesuada leo, vestibulum primis. Consequat feugiat diam congue ut gravida sodales senectus praesent, diam vitae.</p></div></div></div></div></div></div></div></div></div></div></div></div></div><div id="op3-element-gAqor0eh" class="op3-element " data-op3-uuid="gAqor0eh" data-op3-gid="" data-op3-element-type="section" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="video" data-op3-src="" data-op3-video-source="embed" data-op3-video-url-youtube="" data-op3-video-url-vimeo="" data-op3-video-url-wistia="" data-op3-video-autoplay="1" data-op3-video-mute="1" data-op3-video-loop="1" data-op3-video-controls="0" data-op3-video-modest-branding="1" data-op3-video-related="0" data-op3-video-color="#00adef" data-op3-video-background="1" data-op3-video-byline="0" data-op3-video-portrait="0" data-op3-video-title="0" data-op3-video-speed="0" data-op3-video-start-time="00:00" data-op3-show-on-mobile="1"><div data-op3-code data-op3-aspect-ratio="16:9"></div></div><div data-op3-background="overlay"></div><div data-op3-background="separatorTop"></div><div data-op3-background="separatorBottom"></div></div><div data-op3-children="1"><div id="op3-element-cd4uws2A" class="op3-element " data-op3-uuid="cd4uws2A" data-op3-gid="" data-op3-element-type="row" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="3" data-op3-stack-columns-tablet="0" data-op3-stack-columns-tablet-reverse="0" data-op3-stack-columns-mobile="1" data-op3-stack-columns-mobile-reverse="0" data-op3-wrap-columns="0"><div id="op3-element-iLuaj4it" class="op3-element " data-op3-uuid="iLuaj4it" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-i1yZrbtf" class="op3-element " data-op3-uuid="i1yZrbtf" data-op3-gid="" data-op3-element-type="headline" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-headline-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><h2><span style="color: rgb(241, 241, 247); background-color: rgb(0, 0, 0);">Product/Service Viability</span></h2></div></div></div></div></div></div></div><div id="op3-element-tuwLFH8Q" class="op3-element " data-op3-uuid="tuwLFH8Q" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-fvrGxCn5" class="op3-element " data-op3-uuid="fvrGxCn5" data-op3-gid="" data-op3-element-type="headline" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-headline-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><h2>00/</h2></div></div></div></div></div></div></div><div id="op3-element-8H9Aw8pK" class="op3-element " data-op3-uuid="8H9Aw8pK" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-PqFFpHZs" class="op3-element " data-op3-uuid="PqFFpHZs" data-op3-gid="" data-op3-element-type="headline" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-headline-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><h2>000</h2></div></div></div></div></div></div></div></div></div></div></div></div></div><div id="op3-element-R6Efczo0" class="op3-element " data-op3-uuid="R6Efczo0" data-op3-gid="" data-op3-element-type="section" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="video" data-op3-src="" data-op3-video-source="embed" data-op3-video-url-youtube="" data-op3-video-url-vimeo="" data-op3-video-url-wistia="" data-op3-video-autoplay="1" data-op3-video-mute="1" data-op3-video-loop="1" data-op3-video-controls="0" data-op3-video-modest-branding="1" data-op3-video-related="0" data-op3-video-color="#00adef" data-op3-video-background="1" data-op3-video-byline="0" data-op3-video-portrait="0" data-op3-video-title="0" data-op3-video-speed="0" data-op3-video-start-time="00:00" data-op3-show-on-mobile="1"><div data-op3-code data-op3-aspect-ratio="16:9"></div></div><div data-op3-background="overlay"></div><div data-op3-background="separatorTop"></div><div data-op3-background="separatorBottom"></div></div><div data-op3-children="1"><div id="op3-element-GMJQ0Dgw" class="op3-element " data-op3-uuid="GMJQ0Dgw" data-op3-gid="" data-op3-element-type="row" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1" data-op3-stack-columns-tablet="0" data-op3-stack-columns-tablet-reverse="0" data-op3-stack-columns-mobile="1" data-op3-stack-columns-mobile-reverse="0" data-op3-wrap-columns="0"><div id="op3-element-VSkdtP4k" class="op3-element " data-op3-uuid="VSkdtP4k" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-cqimyta3" class="op3-element " data-op3-uuid="cqimyta3" data-op3-gid="" data-op3-element-type="text" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-text-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><p>Purus ad semper aliquam nunc ad diam donec commodo. Amet justo placerat condimentum! Inceptos phasellus leo erat nisl? Dictumst pulvinar ornare maecenas vitae sodales sollicitudin sit enim sapien placerat auctor! Dui habitant vivamus conubia donec, malesuada leo, vestibulum primis. Consequat feugiat diam congue ut gravida sodales senectus praesent, diam vitae.</p></div></div></div></div></div></div></div></div></div></div></div></div></div><div id="op3-element-zbzqrSEV" class="op3-element " data-op3-uuid="zbzqrSEV" data-op3-gid="" data-op3-element-type="section" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="video" data-op3-src="" data-op3-video-source="embed" data-op3-video-url-youtube="" data-op3-video-url-vimeo="" data-op3-video-url-wistia="" data-op3-video-autoplay="1" data-op3-video-mute="1" data-op3-video-loop="1" data-op3-video-controls="0" data-op3-video-modest-branding="1" data-op3-video-related="0" data-op3-video-color="#00adef" data-op3-video-background="1" data-op3-video-byline="0" data-op3-video-portrait="0" data-op3-video-title="0" data-op3-video-speed="0" data-op3-video-start-time="00:00" data-op3-show-on-mobile="1"><div data-op3-code data-op3-aspect-ratio="16:9"></div></div><div data-op3-background="overlay"></div><div data-op3-background="separatorTop"></div><div data-op3-background="separatorBottom"></div></div><div data-op3-children="1"><div id="op3-element-HTpUcmOz" class="op3-element " data-op3-uuid="HTpUcmOz" data-op3-gid="" data-op3-element-type="row" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="3" data-op3-stack-columns-tablet="0" data-op3-stack-columns-tablet-reverse="0" data-op3-stack-columns-mobile="1" data-op3-stack-columns-mobile-reverse="0" data-op3-wrap-columns="0"><div id="op3-element-8kzyUnXX" class="op3-element " data-op3-uuid="8kzyUnXX" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-XlEpdJKB" class="op3-element " data-op3-uuid="XlEpdJKB" data-op3-gid="" data-op3-element-type="headline" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-headline-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><h2><span style="color: rgb(241, 241, 247); background-color: rgb(0, 0, 0);">General Overall Health</span></h2></div></div></div></div></div></div></div><div id="op3-element-9Yh1rrBi" class="op3-element " data-op3-uuid="9Yh1rrBi" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-7b0H9qci" class="op3-element " data-op3-uuid="7b0H9qci" data-op3-gid="" data-op3-element-type="headline" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-headline-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><h2>00/</h2></div></div></div></div></div></div></div><div id="op3-element-Yi2lpXF9" class="op3-element " data-op3-uuid="Yi2lpXF9" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-OCQ5EEfc" class="op3-element " data-op3-uuid="OCQ5EEfc" data-op3-gid="" data-op3-element-type="headline" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-headline-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><h2>000</h2></div></div></div></div></div></div></div></div></div></div></div></div></div><div id="op3-element-esd2tDTW" class="op3-element " data-op3-uuid="esd2tDTW" data-op3-gid="" data-op3-element-type="section" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="video" data-op3-src="" data-op3-video-source="embed" data-op3-video-url-youtube="" data-op3-video-url-vimeo="" data-op3-video-url-wistia="" data-op3-video-autoplay="1" data-op3-video-mute="1" data-op3-video-loop="1" data-op3-video-controls="0" data-op3-video-modest-branding="1" data-op3-video-related="0" data-op3-video-color="#00adef" data-op3-video-background="1" data-op3-video-byline="0" data-op3-video-portrait="0" data-op3-video-title="0" data-op3-video-speed="0" data-op3-video-start-time="00:00" data-op3-show-on-mobile="1"><div data-op3-code data-op3-aspect-ratio="16:9"></div></div><div data-op3-background="overlay"></div><div data-op3-background="separatorTop"></div><div data-op3-background="separatorBottom"></div></div><div data-op3-children="1"><div id="op3-element-p0nzriHa" class="op3-element " data-op3-uuid="p0nzriHa" data-op3-gid="" data-op3-element-type="row" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1" data-op3-stack-columns-tablet="0" data-op3-stack-columns-tablet-reverse="0" data-op3-stack-columns-mobile="1" data-op3-stack-columns-mobile-reverse="0" data-op3-wrap-columns="0"><div id="op3-element-WI6hzruQ" class="op3-element " data-op3-uuid="WI6hzruQ" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-Xo3D1AQS" class="op3-element " data-op3-uuid="Xo3D1AQS" data-op3-gid="" data-op3-element-type="text" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-text-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><p>Purus ad semper aliquam nunc ad diam donec commodo. Amet justo placerat condimentum! Inceptos phasellus leo erat nisl? Dictumst pulvinar ornare maecenas vitae sodales sollicitudin sit enim sapien placerat auctor! Dui habitant vivamus conubia donec, malesuada leo, vestibulum primis. Consequat feugiat diam congue ut gravida sodales senectus praesent, diam vitae.</p></div></div></div></div></div></div></div></div></div></div></div></div></div><div id="op3-element-A78BYFDH" class="op3-element " data-op3-uuid="A78BYFDH" data-op3-gid="" data-op3-element-type="section" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="video" data-op3-src="" data-op3-video-source="embed" data-op3-video-url-youtube="" data-op3-video-url-vimeo="" data-op3-video-url-wistia="" data-op3-video-autoplay="1" data-op3-video-mute="1" data-op3-video-loop="1" data-op3-video-controls="0" data-op3-video-modest-branding="1" data-op3-video-related="0" data-op3-video-color="#00adef" data-op3-video-background="1" data-op3-video-byline="0" data-op3-video-portrait="0" data-op3-video-title="0" data-op3-video-speed="0" data-op3-video-start-time="00:00" data-op3-show-on-mobile="1"><div data-op3-code data-op3-aspect-ratio="16:9"></div></div><div data-op3-background="overlay"></div><div data-op3-background="separatorTop"></div><div data-op3-background="separatorBottom"></div></div><div data-op3-children="3"><div id="op3-element-WxGLPSNM" class="op3-element " data-op3-uuid="WxGLPSNM" data-op3-gid="" data-op3-element-type="row" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1" data-op3-stack-columns-tablet="0" data-op3-stack-columns-tablet-reverse="0" data-op3-stack-columns-mobile="1" data-op3-stack-columns-mobile-reverse="0" data-op3-wrap-columns="0"><div id="op3-element-4Jw7knKe" class="op3-element " data-op3-uuid="4Jw7knKe" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-aK9Kst2C" class="op3-element " data-op3-uuid="aK9Kst2C" data-op3-gid="" data-op3-element-type="horizontalline" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><hr class="horizontal-line" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" /></div></div></div></div></div></div></div></div><div id="op3-element-KOU5ikGw" class="op3-element " data-op3-uuid="KOU5ikGw" data-op3-gid="" data-op3-element-type="row" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1" data-op3-stack-columns-tablet="0" data-op3-stack-columns-tablet-reverse="0" data-op3-stack-columns-mobile="1" data-op3-stack-columns-mobile-reverse="0" data-op3-wrap-columns="0"><div id="op3-element-0B1uBgRD" class="op3-element " data-op3-uuid="0B1uBgRD" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-zmtNxLr8" class="op3-element " data-op3-uuid="zmtNxLr8" data-op3-gid="" data-op3-element-type="text" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><div class="op3-text-wrapper" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-contenteditable><p><span style="color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 14.4px; font-weight: 700;"><i>This scorecard presents your overall strength in each of the five critical factors that contribute to business success. Each of the 20 different Key Performance Indicator (KPI) sections that you have responded to has been taken into consideration in these calculations. If you would like to get more detailed information and explore the scores across each of the 20 KPIs, click on the button below to set up a 1-on-1 conference with one of MarketAtomy's experienced professionals.</i></span><br></p></div></div></div></div></div></div></div></div></div></div><div id="op3-element-X8WGA0l7" class="op3-element " data-op3-uuid="X8WGA0l7" data-op3-gid="" data-op3-element-type="row" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div data-op3-element-container data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0" data-op3-sticky="0" data-op3-sticky-active-desktop="1" data-op3-sticky-active-tablet="1" data-op3-sticky-active-mobile="0" data-op3-sticky-top-desktop="0" data-op3-sticky-top-tablet="0" data-op3-sticky-top-mobile="0" data-op3-sticky-until="0" data-op3-sticky-until-element=""><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1" data-op3-stack-columns-tablet="0" data-op3-stack-columns-tablet-reverse="0" data-op3-stack-columns-mobile="1" data-op3-stack-columns-mobile-reverse="0" data-op3-wrap-columns="0"><div id="op3-element-kPPPV6RW" class="op3-element " data-op3-uuid="kPPPV6RW" data-op3-gid="" data-op3-element-type="column" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="1"><div class="op3-column-content op3-background-parent" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-element-container><div data-op3-border><div data-op3-background="base"></div><div data-op3-background="image"></div><div data-op3-background="overlay"></div></div><div data-op3-children="1"><div id="op3-element-105rdMZh" class="op3-element " data-op3-uuid="105rdMZh" data-op3-gid="" data-op3-element-type="button" data-op3-element-spec="" data-op3-code-before="" data-op3-code-after="" data-op3-visibility-hidden="0" data-op3-element-hidden="0" data-op3-style-id="" data-op3-has-children="0"><a href="https://calendly.com/dannaolivo/bhc-1-on-1-consult" class="op3-background-ancestor" target="_blank"  data-op-action="link" data-op-popoverlay-trigger="none" data-op-select-funnel-step="" data-op-animation-trigger="none" data-op-animation-style="" data-op-animation-loop="0" data-op-timer-minutes="0" data-op-timer-seconds="0"><div data-op3-background="overlay"></div><div data-op3-border></div><div class="op3-text-container"><i class="op3-icon op3-icon-small-right" data-op3-icon="op3-icon-small-right"></i><span class="op3-divider"></span><div class="op3-text" data-op3-contenteditable><div>Yes, I Want To Know More!</div></div></div><div class="op3-subtext op3-html2" data-op3-contenteditable><div>Sub Text</div></div></a></div></div></div></div></div></div></div></div></div></div></div></div>
</div><!-- #op3-designer-element -->

<script type="text/html" id="tmpl-wp-playlist-current-item">
	<# if ( data.image ) { #>
	<img src="{{ data.thumb.src }}" alt="" />
	<# } #>
	<div class="wp-playlist-caption">
		<span class="wp-playlist-item-meta wp-playlist-item-title">
		&#8220;{{ data.title }}&#8221;		</span>
		<# if ( data.meta.album ) { #><span class="wp-playlist-item-meta wp-playlist-item-album">{{ data.meta.album }}</span><# } #>
		<# if ( data.meta.artist ) { #><span class="wp-playlist-item-meta wp-playlist-item-artist">{{ data.meta.artist }}</span><# } #>
	</div>
</script>
<script type="text/html" id="tmpl-wp-playlist-item">
	<div class="wp-playlist-item">
		<a class="wp-playlist-caption" href="{{ data.src }}">
			{{ data.index ? ( data.index + '. ' ) : '' }}
			<# if ( data.caption ) { #>
				{{ data.caption }}
			<# } else { #>
				<span class="wp-playlist-item-title">
				&#8220;{{{ data.title }}}&#8221;				</span>
				<# if ( data.artists && data.meta.artist ) { #>
				<span class="wp-playlist-item-artist"> &mdash; {{ data.meta.artist }}</span>
				<# } #>
			<# } #>
		</a>
		<# if ( data.meta.length_formatted ) { #>
		<div class="wp-playlist-item-length">{{ data.meta.length_formatted }}</div>
		<# } #>
	</div>
</script>
	        <ul style="display: none;">
            <li id="mpp-loader-wrapper" style="display:none;" class="mpp-loader">
                <div id="mpp-loader"><img
                            src="https://www.marketatomy.com/wp-content/plugins/mediapress/templates/mediapress/default/assets/images/loader.gif"/></div>
            </li>
        </ul>

        <div id="mpp-cover-uploading" style="display:none;" class="mpp-cover-uploading">
            <img src="https://www.marketatomy.com/wp-content/plugins/mediapress/templates/mediapress/default/assets/images/loader.gif"/>
        </div>


				<script>
		( function ( body ) {
			'use strict';
			body.className = body.className.replace( /\btribe-no-js\b/, 'tribe-js' );
		} )( document.body );
		</script>
		<script> /* <![CDATA[ */var tribe_l10n_datatables = {"aria":{"sort_ascending":": activate to sort column ascending","sort_descending":": activate to sort column descending"},"length_menu":"Show _MENU_ entries","empty_table":"No data available in table","info":"Showing _START_ to _END_ of _TOTAL_ entries","info_empty":"Showing 0 to 0 of 0 entries","info_filtered":"(filtered from _MAX_ total entries)","zero_records":"No matching records found","search":"Search:","all_selected_text":"All items on this page were selected. ","select_all_link":"Select all pages","clear_selection":"Clear Selection.","pagination":{"all":"All","next":"Next","previous":"Previous"},"select":{"rows":{"0":"","_":": Selected %d rows","1":": Selected 1 row"}},"datepicker":{"dayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"dayNamesShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"dayNamesMin":["S","M","T","W","T","F","S"],"monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesShort":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesMin":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"nextText":"Next","prevText":"Prev","currentText":"Today","closeText":"Done","today":"Today","clear":"Clear"},"registration_prompt":"There is unsaved attendee information. Are you sure you want to continue?"};/* ]]> */ </script><!-- This site is converting visitors into subscribers and customers with OptinMonster - https://optinmonster.com :: Campaign Title: GDPR Statement --><script>(function(d){var s=d.createElement('script');s.type='text/javascript';s.src='https://a.omappapi.com/app/js/api.min.js';s.async=true;s.dataset.campaign='wn97difu3ncgppfuee6j';s.dataset.user='98988';d.getElementsByTagName('head')[0].appendChild(s);})(document);</script><!-- / OptinMonster --><!-- This site is converting visitors into subscribers and customers with OptinMonster - https://optinmonster.com :: Campaign Title: Free Report - 5 Tips Side Hustle --><script>(function(d){var s=d.createElement('script');s.type='text/javascript';s.src='https://a.omappapi.com/app/js/api.min.js';s.async=true;s.dataset.campaign='tccceo5a4asj3qmd8ocv';s.dataset.user='98988';d.getElementsByTagName('head')[0].appendChild(s);})(document);</script><!-- / OptinMonster -->		<script type="text/javascript">
		var wn97difu3ncgppfuee6j_shortcode = true;var tccceo5a4asj3qmd8ocv_shortcode = true;		</script>
		<script type='text/javascript' src='https://www.marketatomy.com/wp-content/plugins/op-builder/public/assets/cache/page-16288.js?ver=925707738a5757bf276d595acb834803'></script>
<script type='text/javascript' src='https://www.marketatomy.com/wp-includes/js/wp-embed.min.js?ver=5.4.5'></script>
<script type='text/javascript' src='https://www.marketatomy.com/wp-content/plugins/optinmonster/assets/js/helper.js?ver=2.3.1'></script>
		<script type="text/javascript">var omapi_localized = { ajax: 'https://www.marketatomy.com/wp-admin/admin-ajax.php?optin-monster-ajax-route=1', nonce: 'a5d4d5e9e9', slugs: {"wn97difu3ncgppfuee6j":{"slug":"wn97difu3ncgppfuee6j","mailpoet":false},"tccceo5a4asj3qmd8ocv":{"slug":"tccceo5a4asj3qmd8ocv","mailpoet":false}} };</script>
				<script type="text/javascript">var omapi_data = {"wc_cart":[],"object_id":16288,"object_key":"page","object_type":"post","term_ids":[]};</script>
		        <a class="op3badge" target="_blank" href="https://www.optimizepress.com">
            <img alt="Page Created with OptimizePress" src="https://www.marketatomy.com/wp-content/plugins/op-builder/public/assets/img/op3badge.svg" />
        </a>
    </body>
</html>

